from ui.interfaz import iniciar_interfaz

if __name__ == "__main__":
    iniciar_interfaz()
