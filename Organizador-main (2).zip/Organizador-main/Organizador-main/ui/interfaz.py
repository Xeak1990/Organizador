import threading
import customtkinter as ctk
from tkinter import filedialog, messagebox
from core.organizador import organizar_archivos

def seleccionar_carpeta(var):
    ruta = filedialog.askdirectory()
    if ruta:
        var.set(ruta)

def iniciar_proceso(carpeta_origen, progreso, salida, ventana):
    def tarea():
        try:
            organizar_archivos(carpeta_origen.get(), progreso, salida, ventana)
            messagebox.showinfo("Éxito", "Organización completada")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    hilo = threading.Thread(target=tarea)
    hilo.start()

def iniciar_interfaz():
    # Tema
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("blue")

    # Ventana principal
    ventana = ctk.CTk()
    ventana.title("Organizador de Archivos con IA")
    ventana.geometry("750x550")

    # Variables
    carpeta_origen = ctk.StringVar()

    # Título
    titulo = ctk.CTkLabel(
        ventana,
        text="📂 Organizador de Archivos con IA",
        font=("Arial", 22, "bold")
    )
    titulo.pack(pady=20)

    # Campo de carpeta
    frame_carpeta = ctk.CTkFrame(ventana)
    frame_carpeta.pack(pady=10, padx=20, fill="x")

    label_carpeta = ctk.CTkLabel(frame_carpeta, text="Carpeta de origen:")
    label_carpeta.pack(side="left", padx=10, pady=10)

    entry_carpeta = ctk.CTkEntry(frame_carpeta, textvariable=carpeta_origen, width=400)
    entry_carpeta.pack(side="left", padx=10, pady=10)

    boton_carpeta = ctk.CTkButton(
        frame_carpeta,
        text="Seleccionar",
        command=lambda: seleccionar_carpeta(carpeta_origen)
    )
    boton_carpeta.pack(side="left", padx=10, pady=10)

    # Barra de progreso
    progreso = ctk.CTkProgressBar(ventana, width=500)
    progreso.set(0)
    progreso.pack(pady=20)

    # Botón de inicio
    boton_iniciar = ctk.CTkButton(
        ventana,
        text="🚀 Iniciar Organización",
        fg_color="#1f6aa5",
        hover_color="#144870",
        command=lambda: iniciar_proceso(carpeta_origen, progreso, salida, ventana)
    )
    boton_iniciar.pack(pady=20)

    # Caja de salida/log
    salida = ctk.CTkTextbox(ventana, width=700, height=200)
    salida.pack(pady=20, padx=20)

    # Iniciar la app
    ventana.mainloop()